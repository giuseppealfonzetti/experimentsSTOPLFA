## usethis namespace: start
#' @useDynLib plFA, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
## usethis namespace: start
#' @import RcppEigen
## usethis namespace: end
NULL

## usethis namespace: start
#' @import RcppParallel
## usethis namespace: end
NULL

## usethis namespace: start
#' @import RcppClock
## usethis namespace: end
NULL

