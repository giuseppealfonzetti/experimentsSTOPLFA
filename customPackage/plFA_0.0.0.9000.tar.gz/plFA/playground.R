###########
set.seed(123)
p <- 6; q <- 4; n <- 50
par <- rnorm(q*(q-1)/2)

S <- get_S(THETA = par, Q = q)
S2 <- get_S2(THETA = par, Q = q)
S;S2

U <- get_U(THETA = par, Q = q)
U2 <- get_U2(THETA = par, Q = q)
U;U2

# par <- rep(0, q*(q-1)/2)
idx <- 3
{
  R_S <- function(TRHO){
    vec <- par
    vec[idx+1] <- TRHO
    S <- get_S(THETA = vec, Q = q)
    S
  }
  R_S(par[idx+1])
  # numgr <- matrix(0, q, q)
  # numgr[upper.tri(numgr, diag = T)] <- numDeriv::jacobian(R_S, transformed_rhos[idx+1])
  # numgr
  numgr <- numDeriv::jacobian(R_S,par[idx+1])
  numgr <- matrix(as.vector(numgr),q,q)

  gr <- grad_S(A = matrix(1,p,q), THETA = par, IDX = idx)
  gr2 <- grad_S2(A = matrix(1,p,q), THETA = par, IDX = idx)

}
gr; gr2
numgr

########################
library(RcppClock)
set.seed(1)
p <- 18; q <- 4; n <- 500
A <- build_constrMat(P = p, Q = q, STRUCT = 'crossed', CROSS = 1)
Load <- gen_loadings(CONSTRMAT = A, LB = 0, UB = 1)
thr <- c(-1.2, 0, 1.2 )
S <- get_S(THETA = rnorm(q*(q-1)/2), Q = q)
which(1-diag(Load%*%S%*%t(Load)) < 0)

for (j in 1:p) {
  if(t(Load[j,])%*%S%*%(Load[j,])>=1){
    Load[j,] <- Load[j,]/  as.numeric((t(Load[j,])%*%S%*%(Load[j,])) + 1e-2)
  }
}
which(1-diag(Load%*%S%*%t(Load)) < 0)

D <- sim_data(
  SAMPLE_SIZE = n,
  LOADINGS = Load,
  THRESHOLDS = thr,
  LATENT_COV = S)
cat <- apply(D, 2, max) + 1
theta <- get_theta(rep(thr, p), Load, S, cat, A)
f <- compute_frequencies(Y = D, C_VEC = cat)
1-diag(Load%*%S%*%t(Load))

lambda0_init <- c()
s <- 0

for (i in 1:length(cat)) {
  vec <- 1:(cat[i]-1)
  vec <- (vec -min(vec))/(max(vec)-min(vec))*(2)-1
  lambda0_init[(s + 1):(s + cat[i] - 1)] <- vec
  s <- s + cat[i] - 1
}
lambda_init = rep(.5, sum(A))
transformed_rhos_init = rep(0, q*(q-1)/2)
#get_Sigma_u2(constrMat, transformed_rhos_init)

par_init <- c(lambda0_init, lambda_init, transformed_rhos_init)
#par_init <- theta+rnorm(length(theta))
mean((par_init-theta)^2)

K = p*(p-1)/2; K

my_seq <- seq(0, 10000, 100)

st <- fit_plFA(
  DATA = D,
  CONSTR_LIST = list('CONSTRMAT' = A, 'CORRFLAG'=1),
  # VALDATA = sim_data(
  #   SAMPLE_SIZE = 10000,
  #   LOADINGS = Load,
  #   THRESHOLDS = thr,
  #   LATENT_COV = S,
  #   SEED = 1),
  METHOD = 'hyper',
  CONTROL = list(PAIRS_PER_ITERATION = 8, MAXT = 10000, ETA = .005, BURN = 5000, PAR3 = .75, EACHCHECK = 500, CHECKCONV = 1, TOL = 1e-3, TOLCOUNT = 3),#cpp_ctrl,
  INIT = NULL,
  ITERATIONS_SUBSET = my_seq,
  NCORES = 8
)
st
mean((getPar(st)-getPar(theta, OPTION = 'transformed', C = sum(cat), P = p, Q = q, CONSTRMAT = A))^2)
st@freqTime; st@RTime
st@stoFit@pathValNll
st@stoFit@lastIter
st@stoFit@convergence
# st@valfreq[, 1:10]
# st@freq[, 1:10]
th <- st@theta
getPar(st)-getPar(th, OPTION = 'transformed', C = sum(cat), P = p, Q = q, CONSTRMAT = A)


getThetaPath(OBJ = st, LAB = 'pathTheta', OPTION = 'transformed') |> pluck('iter')
getThetaPath(st) %>% pluck('par')

st@stoFit@pathValNll
st@stoFit@pathValNll[,2] |> diff()

which(getPar(st)-getPar(theta, OPTION = 'transformed', C = sum(cat), P = p, Q = q, CONSTRMAT = A)>1)
lst <- getPar(st, OPTION = 'list')
matrixcalc::is.positive.definite( lst$latent_correlations, tol = 1e-8 )

modcor <- lst$loadings%*%lst$latent_correlations%*%t(lst$loadings)
modcor <- (modcor + t(modcor))/2
diag(modcor) <- 1
matrixcalc::is.positive.definite( modcor, tol = 1e-8 )
diag(lst$loadings%*%lst$latent_correlations%*%t(lst$loadings))

getPar(st, OPTION = 'list')$latent_correlations; S

st@stoFit@control



getPar(st, OPTION = 'list')
getPar(st, OPTION = 'list')$latent_correlations; S
getPar(theta, OPTION = 'list', C = sum(cat), P = p, Q = q, CONSTRMAT = A)
st@theta
theta
mean((st@theta-theta)^2)
get_S2(st@theta, q); S
st$control

dim(getThetaPath(st))
length(st@stoFit@trajSubset)

list(st@stoFit@pathTheta)
getThetaPath(st, 'pathTheta')

st@stoFit[['pathTheta']]
numFit <- fit_plFA(
  DATA = D,
  CONSTR_LIST = list('CONSTRMAT' = A, 'CORRFLAG' = 1),
  METHOD = 'ucminf',
  CONTROL = list(),
  INIT = NULL,
  NCORES = 1)
numFit
# mean((numFit@theta - theta)^2)
mean((getPar(numFit)-getPar(theta, OPTION = 'transformed', C = sum(cat), P = p, Q = q, CONSTRMAT = A))^2)

getPar(numFit, OPTION = 'list');S
numFit@numFit$message
getThetaPath(numFit, 'pathTheta')
mean((getPar(numFit)-getPar(theta, OPTION = 'transformed', C = sum(cat), P = p, Q = q, CONSTRMAT = A))^2)
getPar(numFit, OPTION = 'list')$loadings-Load
getPar(numFit, OPTION = 'list')$thresholds



lst <- getPar(numFit, OPTION = 'list');S
matrixcalc::is.positive.definite( lst$latent_correlations, tol = 1e-8 )

modcor <- lst$loadings%*%lst$latent_correlations%*%t(lst$loadings)
modcor <- (modcor + t(modcor))/2
diag(modcor) <- 1
matrixcalc::is.positive.definite( modcor, tol = 1e-8 )

1-diag(Load%*%S%*%t(Load))
diag(lst$loadings%*%lst$latent_correlations%*%t(lst$loadings))-diag(Load%*%S%*%t(Load))
det(lst$latent_correlations)
Load
numFit
tmp <- numFit$tmp
tst <- new('dimensions', p=10)
tst@q <- 4
tst
tmp
tst <- stoc_args(list(), P = p)

fr <- pairs_freq(D, C_VEC = cat)

H <- estimate_H(cat, A, numFit@theta, fr, n, 1)$est_H
H <- (H+t(H))/2
H$gradient
matrixcalc::is.positive.definite( as.matrix(H), tol = 1e-8 )
sum(is.na(H))
Hinv <- solve(H)
det(H)
J <- estimate_J(D, cat, A, theta, 1)$est_J
J

sndw <- Hinv%*%J%*%Hinv
numvar <- computeVar(OBJ = numFit, DATA = D, NUMDERIV = T, OPTION = 'transformed')
stovar <- computeVar(OBJ = st, DATA = D, NUMDERIV = T, OPTION = 'transformed')
numse <- sqrt(numvar$asymptotic_variance)
stose <- sqrt(stovar$optimisation_noise+stovar$asymptotic_variance)

numse-numseOLD
stose-stoseOLD


var1 <- computeVar(numFit, DATA = D, NUMDERIV = F)$asymptotic_variance
var2 <- computeVar(numFit, DATA = D, NUMDERIV = T)$asymptotic_variance
cbind(var1,var2)
